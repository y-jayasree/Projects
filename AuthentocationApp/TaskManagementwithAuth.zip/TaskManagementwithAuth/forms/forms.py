from django import forms
from .models import Student

class StudentForm(forms.Form):
    name = forms.CharField(max_length=50)
    desc = forms.CharField(widget=forms.Textarea)
    email = forms.EmailField()