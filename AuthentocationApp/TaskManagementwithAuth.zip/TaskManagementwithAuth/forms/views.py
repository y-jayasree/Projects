from django.shortcuts import render
from .models import *
from .forms import *
# Create your views here.

def display(request):
    a = Student.objects.all()
    return render(request, 'display.html', {'k':a})

def create(request):
    if request.method == 'POST':
        b = request.POST['name']
        c = request.POST['desc']
        d = request.POST['email']
        Student.objects.create(name=b, desc=c, email=d)
    a = StudentForm()
    return render(request, 'form.html', {'k':a})