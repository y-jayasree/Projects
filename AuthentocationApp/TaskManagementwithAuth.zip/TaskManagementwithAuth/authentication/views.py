from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login

# from django.contrib.auth.mixins import LoginRequiredMixin
# Create your views here.

def register(request):
    if request.method == 'POST':
        un = request.POST['a']
        em = request.POST['b']
        ps = request.POST['c']
        cp = request.POST['d']
        if ps == cp :
            User.objects.create_user(username=un, email=em, password=ps)
            messages.success(request, 'Account Created Successfully')
            return redirect('login1')
        else:
            messages.error(request, 'passwords are mismatching')
    return render(request, 'register123.html')


def login1(request):
    if request.method == 'POST':
        un = request.POST.get('a')
        ps = request.POST.get('c')
        data = authenticate(request, username=un, password=ps)
        print(data)
        if data:
            login(request, data)
            return redirect('home')
    return render(request, 'login123.html')






'''
def login1(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        print(user)
        if user is not None:
            login(request, user)
            return redirect('home') # Ensure 'home' is a valid URL pattern name
    return render(request, 'login123.html')
'''