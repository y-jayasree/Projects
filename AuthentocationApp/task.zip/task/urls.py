from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home, name='home'),
    path('add_task/', views.add_task, name='add'),
    path('update/<int:id>', views.update, name='update'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('history/', views.history_read, name='history'),
    path('restore/<int:id>', views.restore, name='restore'),
    path('history_delete/<int:id>', views.history_delete, name='history_delete'),
    path('restore_all/', views.restore_all, name='restore_all'),
    path('delete_all/', views.delete_all, name='delete_all'),
    path('register/', views.register, name='register'),
    path('', views.login1, name='login123'),
    path('logout/', views.logout1, name='logout')
]