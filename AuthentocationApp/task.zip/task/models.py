from django.db import models

# Create your models here.

class TaskModel(models.Model):
    name = models.CharField(max_length=60)
    desc = models.TextField()
    deadline = models.DateTimeField()

class HistoryTaskModel(models.Model):
    name = models.CharField(max_length=60)
    desc = models.TextField()
    deadline = models.DateTimeField()

class Registration(models.Model):
    un = models.CharField(max_length=50)
    email = models.EmailField()
    contact = models.IntegerField()
    pswd = models.CharField(max_length=100)