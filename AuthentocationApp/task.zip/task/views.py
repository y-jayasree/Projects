from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import TaskModel, HistoryTaskModel
from django.contrib.auth.decorators import login_required
from django.contrib.auth import decorators
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

@login_required
def home(request):
    a = TaskModel.objects.all()
    return render(request, 'nav.html', {'k':a})

@login_required
def add_task(request):
    if request.method=='POST':
        a = request.POST['title']
        b = request.POST['desc']
        c = request.POST['deadline']
        TaskModel.objects.create(name=a, desc=b, deadline=c)
        return redirect('home')
    return render(request, 'add.html')

def update(request, id):
    a=TaskModel.objects.get(id=id)
    if request.method=='POST':
        a.name = request.POST['title']
        a.desc = request.POST['desc']
        a.deadline = request.POST['deadline']
        a.save()
        return redirect('home')
    return render(request, 'update.html', {'d':a})

def delete(request, id):
    a=TaskModel.objects.get(id=id)
    b=HistoryTaskModel.objects.create(name=a.name, desc=a.desc, deadline=a.deadline)
    b.save()
    a.delete()
    return redirect('home')

def history_read(request):
    a = HistoryTaskModel.objects.all()
    return render(request, 'history.html', {'k':a})

def restore(request, id):
    a=HistoryTaskModel.objects.get(id=id)
    b=TaskModel.objects.create(name=a.name, desc=a.desc, deadline=a.deadline)
    b.save()
    a.delete()
    return redirect('home')

def history_delete(request, id):
    HistoryTaskModel.objects.get(id=id).delete()
    return redirect('history')

def restore_all(request):
    a = HistoryTaskModel.objects.all()
    for i in a:
        b = TaskModel.objects.create(name=i.name, desc=i.desc, deadline=i.deadline)
        b.save()
    a.delete()
    return redirect('history')

def delete_all(request):
    HistoryTaskModel.objects.all().delete()
    return redirect('history')


def register(request):
    if request.method == 'POST':
        un = request.POST['a']
        em = request.POST['b']
        ps = request.POST['c']
        cp = request.POST['d']
        if ps == cp :
            User.objects.create_user(username=un, email=em, password=ps)
            messages.success(request, 'Account Created Successfully')
            return redirect('login1')
        else:
            messages.error(request, 'passwords are mismatching')
    return render(request, 'register123.html')


def login1(request):
    if request.method == 'POST':
        un = request.POST.get('a')
        ps = request.POST.get('c')
        data = authenticate(request, username=un, password=ps)
        print(data)
        if data:
            login(request, data)
            return redirect('home')
    return render(request, 'login123.html')

def logout1(request):
    logout(request)
    return redirect('login123')